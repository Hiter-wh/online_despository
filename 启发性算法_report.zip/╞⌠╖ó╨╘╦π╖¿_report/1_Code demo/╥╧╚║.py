"""
ACA解决TSP
"""
from scipy import spatial
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
num_points = 25
#生成随机点数
points_coordinate = np.random.rand(num_points, 2)  # generate coordinate of points
distance_matrix = spatial.distance.cdist(points_coordinate, points_coordinate, metric='euclidean')

#计算距离总和
def cal_total_distance(routine):
    num_points, = routine.shape
    return sum([distance_matrix[routine[i % num_points], routine[(i + 1) % num_points]] for i in range(num_points)])
"""
class ACA_TSP:
    def __init__(self, func, n_dim,
                 size_pop=10, max_iter=20,
                 distance_matrix=None,
                 alpha=1, beta=2, rho=0.1,
                 ):
        if distance_matrix==None:
            print("为未输入地图\n")

        self.n_dim = n_dim  # 城市数量return null
        self.func = func
        self.size_pop = size_pop  # 蚂蚁数量
        self.max_iter = max_iter  # 迭代次数
        self.alpha = alpha  # 信息素重要程度
        self.beta = beta  # 适应度的重要程度
        self.rho = rho  # 信息素挥发速度

        self.prob_matrix_distance = 1 / (distance_matrix + 1e-10 * np.eye(n_dim, n_dim))
        #计算期望矩阵，也就是每个蚂蚁对于目标城市的向往程度，此处设为与距离成反比，也可以理解为可见度。学名为启发函数
        # 避免除零错误，eye为对角阵

        self.Phe = np.ones((n_dim, n_dim))# 信息素矩阵，每次迭代都会更新
        # 某一代每个蚂蚁的爬行路径存储list
        self.Table = np.zeros((size_pop, n_dim)).astype(np.int)
        self.y = None  # 某一代每个蚂蚁的爬行总距离，用来判断解优劣
        self.generation_best_X, self.generation_best_Y = [], []  # 记录各代的最佳情况
       # self.x_best_history, self.y_best_history = self.generation_best_X, self.generation_best_Y  # 历史原因，为了保持统一
        self.best_x, self.best_y = None, None#全局最短距离

    def run(self, max_iter=None):
        self.max_iter = max_iter or self.max_iter
        for i in range(self.max_iter):  # 对每次迭代
            # 转移概率，无须归一化。
            prob_matrix = (self.Phe ** self.alpha) * (self.prob_matrix_distance) ** self.beta
            #费洛蒙（激素）和启发函数是影响概率矩阵的两个因素
            for j in range(self.size_pop):  # 对每个蚂蚁
                self.Table[j, 0] = 0  # start point，其实可以随机，但没什么区别

                for k in range(self.n_dim - 1):  # 蚂蚁到达的每个节点（所有可以去的节点）
                    taboo_set = set(self.Table[j, :k + 1])  # 已经经过的点，不能再次经过
                    allow_list = list(set(range(self.n_dim)) - taboo_set)  # 在这些点中做选择
                    prob = prob_matrix[self.Table[j, k], allow_list]
                    prob = prob / prob.sum()  # 概率归一化
                    next_point = np.random.choice(allow_list, size=1, p=prob)[0]#根据概率矩阵随机选择一个
                    self.Table[j, k + 1] = next_point
            #至此每只蚂蚁在此轮迭代中的路径已登记完毕
            # 计算距离
            y = np.array([self.func(i) for i in self.Table])

            # 顺便记录历史最好情况
            index_best = y.argmin()#找出最小的历史y
            x_best, y_best = self.Table[index_best, :].copy(), y[index_best].copy()
            self.generation_best_X.append(x_best)
            self.generation_best_Y.append(y_best)

            # 计算需要新涂抹的信息素
            delta_tau = np.zeros((self.n_dim, self.n_dim))
            for j in range(self.size_pop):  # 每个蚂蚁
                for k in range(self.n_dim - 1):  # 每个节点（出发点以外的）
                    n1, n2 = self.Table[j, k], self.Table[j, k + 1]  # 蚂蚁从n1节点爬到n2节点
                    delta_tau[n1, n2] += 1 / y[j]  # 涂抹的信息素，与蚂蚁走过的距离总和成反比
                n1, n2 = self.Table[j, self.n_dim - 1], self.Table[j, 0]  # 蚂蚁从最后一个节点爬回到第一个节点
                delta_tau[n1, n2] += 1 / y[j]  # 涂抹信息素

            # 信息素飘散+信息素涂抹
            self.Phe = (1 - self.rho) * self.Phe + delta_tau

        best_generation = np.array(self.generation_best_Y).argmin()
        self.best_x = self.generation_best_X[best_generation]
        self.best_y = self.generation_best_Y[best_generation]
        return self.best_x, self.best_y

    fit = run
"""
from sko.ACA import ACA_TSP

aca = ACA_TSP(func=cal_total_distance, n_dim=num_points,
              size_pop=50, max_iter=200,
              distance_matrix=distance_matrix)

best_x, best_y = aca.run()
#返回花费最小的那一次的路径和花费
# %% Plot
fig, ax = plt.subplots(1, 2)
best_points_ = np.concatenate([best_x, [best_x[0]]])#加上返回起点那一步
print(best_points_)
best_points_coordinate = points_coordinate[best_points_, :]#第一维，第二维度list全包括，即取所有点
print(best_points_coordinate)
ax[0].plot(best_points_coordinate[:, 0], best_points_coordinate[:, 1], 'o-r')
pd.DataFrame(aca.y_best_history).cummin().plot(ax=ax[1])
plt.show()
