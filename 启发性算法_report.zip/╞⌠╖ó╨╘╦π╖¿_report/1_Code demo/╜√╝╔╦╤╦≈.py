import numpy as np
from scipy import spatial
import matplotlib.pyplot as plt
from matplotlib.ticker import FormatStrFormatter
from matplotlib.animation import FuncAnimation
"""for TSP"""

def cal_total_distance(routine):
    num_points, = routine.shape
    return sum([distance_matrix[routine[i % num_points], routine[(i + 1) % num_points]] for i in range(num_points)])


class TabuSearch(object):
    def __init__(self, x0, max_iter, table_len,lb=5):#x0为初始解
        self.max_iter = max_iter
        self.table_len = table_len
        self.table_count = 0
        self.tabu_table = np.zeros((self.table_len, 2), dtype='int')#[[1,2],[3,4]]
        self.exchange1, self.exchange2 = 0, 0
        self.amnesty = False #赦免
        self.best_x = np.array(x0)
        self.best_y = cal_total_distance(self.best_x)
        self.best_X_history, self.best_Y_history = [self.best_x], [self.best_y]
        self.lb=lb

    def find_newpath(self, x):#交换函数
        x_new = x.copy()
        y_new = cal_total_distance(x)
        for i in range(num_points-1):#num_point为解得个数
            for j in range(i+1, num_points):
                flag_1,flag_2=[],[]
                x_copy = x.copy()#每次都要重置
                x_copy[i], x_copy[j] = x_copy[j], x_copy[i]#解的两点互换
                temp = cal_total_distance(x_copy)
                if temp < y_new:
                    if self.tabu_table[0].any():
                        for k in range(len(self.tabu_table)):
                            flag_1=(self.tabu_table[k]==[i,j])
                            flag_2=(self.tabu_table[k]==[j,i])
                            if (flag_1[0] and flag_1[1]) or (flag_2[0] and flag_2[1]):
                                break
                    else:
                        flag_1,flag_2=[False,False],[False,False]
                    print(flag_1, flag_2)
                    if (flag_1[0] and flag_1[1]) or (flag_2[0] and flag_2[1]):
                        if (temp <= self.lb):  # 此处要展禁忌表的作用
                            x_new = x_copy
                            y_new = temp
                            self.exchange1 = i
                            self.exchange2 = j
                        else:
                            continue

                    else:
                        x_new = x_copy
                        y_new = temp
                        self.exchange1 = i
                        self.exchange2 = j

                #记录产生最优解的那次交换两方的位置
        return x_new, y_new #返回较优解，注意，一个newpath函数只变换一组解的两个地点 而非大幅度改动

    def run(self):
        for i in range(self.max_iter):  # 迭代
            x_new, y_new = self.find_newpath(self.best_x)
            if y_new < self.best_y:#本此迭代中的新结果有更有解
                self.best_x = x_new
                self.best_y = y_new
                self.best_X_history.append(x_new)
                self.best_Y_history.append(y_new)
                index = np.argwhere(self.tabu_table == self.exchange1)
                print("exchange is at",self.exchange1)
                print('index is:',index,'\n')
                if len(index):#该交换表中存在该交换
                    for j in range(len(index)):#index格式为[[a,b]]
                        print(len(index))
                        flag = (self.tabu_table[index[j, 0]] == np.array([self.exchange1, self.exchange2]))
                        #判断是否重复
                        if flag[0] and flag[1]:
                            self.amnesty = True
                            self.tabu_table = np.delete(self.tabu_table, j, 0)
                            self.tabu_table = np.append(self.tabu_table, [[self.exchange1, self.exchange2]], axis=0)



                if self.amnesty:#有赦免则取消赦免，开启下次迭代
                    self.amnesty = False
                elif self.table_count == 3:#表已满，删除而后添加
                    self.tabu_table = np.delete(self.tabu_table, 0, 0)#删除第一行
                    self.tabu_table = np.append(self.tabu_table, [[self.exchange1, self.exchange2]], axis=0)
                else:
                    self.tabu_table[self.table_count, 0] = self.exchange1
                    self.tabu_table[self.table_count, 1] = self.exchange2#如果没有被禁用  则录入禁忌表
                    self.table_count += 1#禁忌表指针滑动
            else:
                self.best_X_history.append(x_new)
                self.best_Y_history.append(y_new)

        return self.best_x, self.best_y

    def plot_final(self):
        fig, ax = plt.subplots(1, 2)
        best_points_ = np.concatenate([best_points, [best_points[0]]])
        best_points_coordinate = points_coordinate[best_points_, :]
        ax[0].plot(self.best_Y_history)
        ax[0].set_xlabel("Iteration")
        ax[0].set_ylabel("Distance")
        ax[1].plot(best_points_coordinate[:, 0], best_points_coordinate[:, 1],
                   marker='o', markerfacecolor='b', color='c', linestyle='-')
        ax[1].xaxis.set_major_formatter(FormatStrFormatter('%.3f'))
        ax[1].yaxis.set_major_formatter(FormatStrFormatter('%.3f'))
        ax[1].set_xlabel("X")
        ax[1].set_ylabel("Y")
        plt.show()

    def plot_animation(self):
        best_x_history = self.best_X_history

        fig2, ax2 = plt.subplots(1, 1)
        ax2.set_title('title', loc='center')
        line = ax2.plot(points_coordinate[:, 0], points_coordinate[:, 1],
                        marker='o', markerfacecolor='b', color='c', linestyle='-')
        ax2.xaxis.set_major_formatter(FormatStrFormatter('%.3f'))
        ax2.yaxis.set_major_formatter(FormatStrFormatter('%.3f'))
        ax2.set_xlabel("X")
        ax2.set_ylabel("Y")
        plt.ion()

        def update_scatter(frame):
            ax2.set_title('iter = ' + str(frame))
            points = best_x_history[frame]
            points = np.concatenate([points, [points[0]]])
            point_coordinate = points_coordinate[points, :]
            plt.setp(line, 'xdata', point_coordinate[:, 0], 'ydata', point_coordinate[:, 1])
            return line

        ani = FuncAnimation(fig2, update_scatter, blit=True, interval=25, frames=len(best_x_history))
        plt.show()
        ani.save('ts_tsp.gif', writer='pillow')


if __name__ == '__main__':
    points_coordinate = np.random.randint(0, 100, (20, 2))
    num_points = points_coordinate.shape[0]
    distance_matrix = spatial.distance.cdist(points_coordinate, points_coordinate, metric='euclidean')

    ts_tsp = TabuSearch(x0=range(num_points), max_iter=100, table_len=5)
    best_points, best_distance = ts_tsp.run()
    print(best_points, best_distance)
    ts_tsp.plot_final()
    ts_tsp.plot_animation()
