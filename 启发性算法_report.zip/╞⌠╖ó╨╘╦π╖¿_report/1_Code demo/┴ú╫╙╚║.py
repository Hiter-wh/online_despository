# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
"""粒子群算法
相当于一群鸟在更大的区域内找到唯一一个食物
不知道食物的具体位置（解的数值），但是知道解的距离，即y值
Particle swarm algorithm
"""
"""
***应用于解方程***
"""


import sys
#宏定义
max_int_size=sys.maxsize
Max_Particle_Num=1000
Max_dim_num=10
Min_limit=[-300,-300]
Max_limit=[300,300]
Max_velocity=[5,5]
lowest_limit=1e-3#一组解为合格解的标准线（与实际结果差最大值）
#PSO： Particle swarm algorithm

# coding: utf-8
import numpy as np
import random
import matplotlib.pyplot as plt
from pylab import mpl
mpl.rcParams['font.sans-serif'] = ['SimHei']   # 雅黑字体
# ----------------------PSO参数设置---------------------------------  
class PSO():
    def __init__(self, Particle_Nums, dimensions, max_iter,w=0.8,c1=2,c2=2,r1=0.6,r2=0.3):
        self.w = w
        self.c1 = c1
        self.c2 = c2
        self.r1 = r1
        self.r2 = r2
        self.Particle_Nums = Particle_Nums  # 粒子数量  
        self.dimensions = dimensions  # 搜索维度  
        self.max_iter = max_iter  # 迭代次数
        # 所有粒子的位置和速度
        self.X = np.zeros((self.Particle_Nums, self.dimensions))#共N行dim列的三维数组[[,],[,],[,]]
        self.V = np.zeros((self.Particle_Nums, self.dimensions))

        self.pbest = np.zeros((self.Particle_Nums, self.dimensions))  # 个体经历的最佳位置和全局最佳位置  
        #不断更新全局最佳变量（每经过单位时间）
        self.gbest = np.zeros((1, self.dimensions))

        self.p_fit = np.zeros(self.Particle_Nums)  # 每一次迭代后，每个个体的历史最佳适应值
        self.fit = 1e10  # 全局最佳适应值,一开始为无穷
        print(self.V,self.X)
    # ---------------------目标函数 函数-----------------------------
    def function(self,Variables:list):
         # 此处填写y的值
        z = (Variables[0]-1)**2+(Variables[1]-1)**2
        z-=0
        return z

    # ---------------------初始化种群----------------------------------
    def init_Population(self):
        print("粒子群初始化开始")
        for i in range(self.Particle_Nums):
            #limits即dimensions
            for j in range(len(Max_limit)):
                #随机给位置,max_limit也就是维度list
                self.X[i][j] = random.uniform(Min_limit[j],Max_limit[j])#宏中手动给出
                self.V[i][j] = random.uniform(0,Max_velocity[j])
            #初始化个人最优解，X[i]为一组解
            self.pbest[i] = self.X[i]
            #计算出全局及个人最优解，即最近距离
            tmp = self.function(self.X[i])
            self.p_fit[i] = tmp

            if(tmp < self.fit):
                self.fit = tmp
                self.gbest = self.X[i]
        print("粒子群初始化完毕")

            # ----------------------更新粒子位置----------------------------------  

    def iterator(self):
        fitness = []
        answers = []
        for t in range(self.max_iter):
            for i in range(self.Particle_Nums):  # 更新gbest\pbest  
                temp = self.function(self.X[i])
                if(temp<=lowest_limit):
                    answer_=[(self.X[i][cnt]) for cnt in range(self.dimensions)]
                    answers.append(answer_)
                    print('一组最佳解为：',answer_)
                    for j in range(self.dimensions):
                        # 随机给位置,max_limit也就是维度list
                        self.X[i][j] = random.uniform(Min_limit[j], Max_limit[j])  # 宏中手动给出
                        self.V[i][j] = random.uniform(0, Max_velocity[j])
                        #重新给合格的点分配新的位置和距离

                temp=self.function(self.X[i])
                if(temp < self.p_fit[i]):  # 更新个体最优
                    self.p_fit[i] = temp#个体最近距离更新
                    self.pbest[i] = self.X[i]#个体最优解更新
                    if (self.p_fit[i] < self.fit):  # 更新全局最优  
                        self.gbest = self.X[i]#全局最优解
                        self.fit = self.p_fit[i]#全局最近距离

            for i in range(self.Particle_Nums):
            
            #
                self.V[i] = self.w * self.V[i] + self.c1 * self.r1 * (self.pbest[i] - self.X[i]) + \
                            self.c2 * self.r2 * (self.gbest - self.X[i])
                self.X[i] = [(self.X[i][cnt] + self.V[i][cnt]) for cnt in range(self.dimensions) ]
            #
            #把新最短距离加入结果中
            fitness.append(self.fit)
            print(self.fit)  # 输出最优值
        print('结果为:',answers)
        return fitness

    # ----------------------程序执行-----------------------  

if __name__ == '__main__':
    print('PSO算法结果：\n')
    my_pso = PSO(Particle_Nums=30, dimensions=2, max_iter=100)
    my_pso.init_Population()
    fitness = my_pso.iterator()
    # -------------------画图--------------------  
    plt.figure(1)
    plt.title("Figure1")
    plt.xlabel("iterators", size=14)
    plt.ylabel("fitness(Distance from positive solution)", size=14)
    t = np.array([t for t in range(0, 100)])
    fitness = np.array(fitness)
    plt.plot(t, fitness, color='b', linewidth=3)
    plt.show()





"""
#另外一个版本：

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# @Time    : 2019/8/20
# @Author  : github.com/guofei9987

import numpy as np
from sko.tools import func_transformer
from .base import SkoBase


class PSO(SkoBase):
    """
    Do PSO (Particle swarm optimization) algorithm.

    This algorithm was adapted from the earlier works of J. Kennedy and
    R.C. Eberhart in Particle Swarm Optimization [IJCNN1995]_.

    The position update can be defined as:

    .. math::

       x_{i}(t+1) = x_{i}(t) + v_{i}(t+1)

    Where the position at the current step :math:`t` is updated using
    the computed velocity at :math:`t+1`. Furthermore, the velocity update
    is defined as:

    .. math::

       v_{ij}(t + 1) = w * v_{ij}(t) + c_{p}r_{1j}(t)[y_{ij}(t) − x_{ij}(t)]
                       + c_{g}r_{2j}(t)[\hat{y}_{j}(t) − x_{ij}(t)]

    Here, :math:`cp` and :math:`cg` are the cognitive and social parameters
    respectively. They control the particle's behavior given two choices: (1) to
    follow its *personal best* or (2) follow the swarm's *global best* position.
    Overall, this dictates if the swarm is explorative or exploitative in nature.
    In addition, a parameter :math:`w` controls the inertia惯量 of the swarm's
    movement.

    .. [IJCNN1995] J. Kennedy and R.C. Eberhart, "Particle Swarm Optimization,"
    Proceedings of the IEEE International Joint Conference on Neural
    Networks, 1995, pp. 1942-1948.

    Parameters
    --------------------
    func : function
        The func you want to do optimal
    dim : int
        Number of dimension, which is number of parameters of func.
    pop : int
        Size of population, which is the number of Particles. We use 'pop' to keep accordance with GA
    max_iter : int
        Max of iter iterations
    lb : array_like
        The lower bound of every variables of func
    ub : array_like
        The upper bound of every variables of func
    constraint_eq : tuple
        equal constraint. Note: not available yet.
    constraint_ueq : tuple
        unequal constraint
    Attributes
    ----------------------
    pbest_x : array_like, shape is (pop,dim)
        best location of every particle in history
    pbest_y : array_like, shape is (pop,1)
        best image of every particle in history
    gbest_x : array_like, shape is (1,dim)
        general best location for all particles in history
    gbest_y : float
        general best image  for all particles in history
    gbest_y_hist : list
        gbest_y of every iteration


    Examples
    -----------------------------
    see https://scikit-opt.github.io/scikit-opt/#/en/README?id=_3-psoparticle-swarm-optimization
    """

    def __init__(self, func, n_dim=None, pop=40, max_iter=150, lb=-1e5, ub=1e5, w=0.8, c1=0.5, c2=0.5,
                 constraint_eq=tuple(), constraint_ueq=tuple(), verbose=False
                 , dim=None):

        n_dim = n_dim or dim  # support the earlier version

        self.func = func_transformer(func)
        self.w = w  # inertia 惯性
        self.cp, self.cg = c1, c2  # parameters to control personal best, global best respectively
        self.pop = pop  # number of particles
        self.n_dim = n_dim  # dimension of particles, which is the number of variables of func
        self.max_iter = max_iter  # max iter
        self.verbose = verbose  # print the result of each iter or not

        self.lb, self.ub = np.array(lb) * np.ones(self.n_dim), np.array(ub) * np.ones(self.n_dim)
        #采用有N个元素的list作为上下限
        assert self.n_dim == len(self.lb) == len(self.ub), 'dim == len(lb) == len(ub) is not True'
        assert np.all(self.ub > self.lb), 'upper-bound must be greater than lower-bound'
        #鲁棒性确认
        self.has_constraint = bool(constraint_ueq)
        self.constraint_ueq = constraint_ueq

        #可行性检测，即是否到达过该城市
        self.is_feasible = np.array([True] * pop)
        #设置高低限度，直接拿list设置
        self.X = np.random.uniform(low=self.lb, high=self.ub, size=(self.pop, self.n_dim))#三维数组

        v_high = self.ub - self.lb
        self.V = np.random.uniform(low=-v_high, high=v_high, size=(self.pop, self.n_dim))  # speed of particles
        self.Y = self.cal_y()  # y = f(x) for all particles

        #初始化
        self.pbest_x = self.X.copy()  # personal best location of every particle in history
        self.pbest_y = np.array([[np.inf]] * pop)  # best image of every particle in history

        self.gbest_x = self.pbest_x.mean(axis=0).reshape(1, -1)  # global best location for all particles
        self.gbest_y = np.inf  # global best y for all particles
        self.gbest_y_hist = []  # gbest_y of every iteration
        self.update_gbest()

        # record verbose values
        self.record_mode = False
        self.record_value = {'X': [], 'V': [], 'Y': []}
        #self.best_x, self.best_y = self.gbest_x, self.gbest_y  # history reasons, will be deprecated

    def check_constraint(self, x):
        # gather all unequal constraint functions
        for constraint_func in self.constraint_ueq:
            if constraint_func(x) > 0:
                return False
        return True

    def update_V(self):
        r1 = np.random.rand(self.pop, self.n_dim)
        r2 = np.random.rand(self.pop, self.n_dim)
        #更新V及方向
        self.V = self.w * self.V + \
                 self.cp * r1 * (self.pbest_x - self.X) + \
                 self.cg * r2 * (self.gbest_x - self.X)
    def update_X(self):
        self.X = self.X + self.V
        self.X = np.clip(self.X, self.lb, self.ub)

    def cal_y(self):
        # calculate y for every x in X
        self.Y = self.func(self.X).reshape(-1, 1)
        return self.Y

    def update_pbest(self):
        '''
        personal best
        :return:
        '''
        #比较当前位置和以往最佳位置谁更小
        self.need_update = self.pbest_y > self.Y
        for idx, x in enumerate(self.X):#枚举编号及枚举值
            if self.need_update[idx]:
                self.need_update[idx] = self.check_constraint(x)
        #
        self.pbest_x = np.where(self.need_update, self.X, self.pbest_x)
        self.pbest_y = np.where(self.need_update, self.Y, self.pbest_y)

    def update_gbest(self):
        '''
        global best
        :return:
        '''
        idx_min = self.pbest_y.argmin()
        if self.gbest_y > self.pbest_y[idx_min]:
            self.gbest_x = self.X[idx_min, :].copy()
            self.gbest_y = self.pbest_y[idx_min]
        #找出最小值并更新

    def recorder(self):
        if not self.record_mode:
            return
        self.record_value['X'].append(self.X)
        self.record_value['V'].append(self.V)
        self.record_value['Y'].append(self.Y)

    def run(self, max_iter=None, precision=1e-7, N=20):
        '''N：多少个点已经在precision的范围内
        precision: None or float
            If precision is None, it will run the number of max_iter steps
            If precision is a float, the loop will stop if continuous N difference between pbest less than precision
        N: int
        '''
        self.max_iter = max_iter or self.max_iter
        c = 0
        for iter_num in range(self.max_iter):
            self.update_V()
            self.recorder()
            self.update_X()
            self.cal_y()
            self.update_pbest()
            self.update_gbest()
            if precision is not None:
                tor_iter = np.amax(self.pbest_y) - np.amin(self.pbest_y)
                if tor_iter < precision:
                    c = c + 1
                    if c > N:
                        break
                else:
                    c = 0
            if self.verbose:
                print('Iter: {}, Best fit: {} at {}'.format(iter_num, self.gbest_y, self.gbest_x))

            self.gbest_y_hist.append(self.gbest_y)
        self.best_x, self.best_y = self.gbest_x, self.gbest_y
        return self.best_x, self.best_y

    fit = run

"""

