import numpy as np
from scipy import spatial
import matplotlib.pyplot as plt
from matplotlib.ticker import FormatStrFormatter
from matplotlib.animation import FuncAnimation

"""
****For TSP**
"""
class SimulatedAnnealing(object):
    def __init__(self, x0, T_max=100, T_min=1e-7, L=300, max_stay_counter=150):
        self.T_max = T_max  # initial temperature
        self.T_min = T_min  # end temperature
        self.L = int(L)  # num of iteration under every temperature（also called Long of Chain）
        self.max_stay_counter = max_stay_counter  # stop if best_y stay unchanged over max_stay_counter times
        self.best_x = np.array(x0)  # initial solution，a list
        self.best_y = cal_total_distance(self.best_x)
        self.T = self.T_max
        self.iteration = 0
        self.best_y_history = [self.best_y]
        self.best_x_history = [self.best_x]
        #初始化完毕

    def get_new_x(self, x):
        x_new = x.copy()
        SWAP, REVERSE, TRANSPOSE = 0, 1, 2#三种模式

        def swap(x_new):#随机交换两个地点
            n1, n2 = np.random.randint(0, len(x_new) - 1, 2)
            if n1 >= n2:
                n1, n2 = n2, n1 + 1#选取两交换点
            x_new[n1], x_new[n2] = x_new[n2], x_new[n1]
            return x_new

        def reverse(x_new):#随即范围内倒叙
            n1, n2 = np.random.randint(0, len(x_new) - 1, 2)
            if n1 >= n2:
                n1, n2 = n2, n1 + 1
            x_new[n1:n2] = x_new[n1:n2][::-1]
            return x_new

        def transpose(x_new):
            # randomly generate n1 < n2 < n3. Notice: not equal
            n1, n2, n3 = sorted(np.random.randint(0, len(x_new) - 2, 3))
            n2 += 1
            n3 += 2
            slice1, slice2, slice3, slice4 = x_new[0:n1], x_new[n1:n2], x_new[n2:n3 + 1], x_new[n3 + 1:]
            x_new = np.concatenate([slice1, slice3, slice2, slice4])#原解切割成四部分之后重新拼接
            return x_new

        new_x_strategy = np.random.randint(3)
        if new_x_strategy == SWAP:
            x_new = swap(x_new)
        elif new_x_strategy == REVERSE:
            x_new = reverse(x_new)
        elif new_x_strategy == TRANSPOSE:
            x_new = transpose(x_new)

        return x_new

    def cool_down(self):
        self.T = self.T_max / (1 + np.log(1 + self.iteration))#温度以对数函数的倒是形式降低

    def isclose(self, a, b, rel_tol=1e-09, abs_tol=1e-30):
        return abs(a - b) <= max(rel_tol * max(abs(a), abs(b)), abs_tol)

    def run(self):
        x_current, y_current = self.best_x, self.best_y
        stay_counter = 0
        while True:
            for i in range(self.L):
                x_new = self.get_new_x(x_current)
                y_new = cal_total_distance(x_new)

                # Metropolis
                df = y_new - y_current
                if df < 0 or np.exp(-df / self.T) > np.random.rand():
                    x_current, y_current = x_new, y_new#一定概率接纳
                    if y_new < self.best_y:
                        self.best_x, self.best_y = x_new, y_new#更新

            self.iteration += 1
            self.cool_down()
            self.best_y_history.append(self.best_y)
            self.best_x_history.append(self.best_x)

            # if best_y stay for max_stay_counter times, stop iteration
            if self.isclose(self.best_y_history[-1], self.best_y_history[-2]):
                stay_counter += 1
            else:
                stay_counter = 0

            if self.T < self.T_min:
                print('Cooled to final temperature')
                break
            if stay_counter > self.max_stay_counter:
                print('Stay unchanged in the last {stay_counter} iterations'.format(stay_counter=stay_counter))
                break

        return self.best_x, self.best_y


def cal_total_distance(routine):
    num_points, = routine.shape
    return sum([distance_matrix[routine[i % num_points], routine[(i + 1) % num_points]] for i in range(num_points)])


def plot_final():
    fig, ax = plt.subplots(1, 2)
    best_points_ = np.concatenate([best_points, [best_points[0]]])
    best_points_coordinate = points_coordinate[best_points_, :]
    ax[0].plot(sa_tsp.best_y_history)
    ax[0].set_xlabel("Iteration")
    ax[0].set_ylabel("Distance")
    ax[1].plot(best_points_coordinate[:, 0], best_points_coordinate[:, 1],
               marker='o', markerfacecolor='b', color='c', linestyle='-')
    ax[1].xaxis.set_major_formatter(FormatStrFormatter('%.3f'))
    ax[1].yaxis.set_major_formatter(FormatStrFormatter('%.3f'))
    ax[1].set_xlabel("X")
    ax[1].set_ylabel("Y")
    plt.show()


def plot_animation():
    best_x_history = sa_tsp.best_x_history

    fig2, ax2 = plt.subplots(1, 1)
    ax2.set_title('title', loc='center')
    line = ax2.plot(points_coordinate[:, 0], points_coordinate[:, 1],
                    marker='o', markerfacecolor='b', color='c', linestyle='-')
    ax2.xaxis.set_major_formatter(FormatStrFormatter('%.3f'))
    ax2.yaxis.set_major_formatter(FormatStrFormatter('%.3f'))
    ax2.set_xlabel("X")
    ax2.set_ylabel("Y")
    plt.ion()

    def update_scatter(frame):#更新帧函数
        ax2.set_title('iter = ' + str(frame))
        points = best_x_history[frame]
        points = np.concatenate([points, [points[0]]])#最后一个点
        point_coordinate = points_coordinate[points, :]
        plt.setp(line, 'xdata', point_coordinate[:, 0], 'ydata', point_coordinate[:, 1])
        return line

    ani = FuncAnimation(fig2, update_scatter, blit=True, interval=25, frames=len(best_x_history))
    plt.show()
    ani.save('sa_tsp.gif', writer='')


if __name__ == '__main__':
    points_coordinate = np.random.randint(0, 100, (20, 2))
    num_points = points_coordinate.shape[0]
    distance_matrix = spatial.distance.cdist(points_coordinate, points_coordinate, metric='euclidean')

    sa_tsp = SimulatedAnnealing(x0=range(num_points), T_max=100, T_min=1, L=10 * num_points)
    best_points, best_distance = sa_tsp.run()
    print(best_points, best_distance)

    plot_final()
    plot_animation()


