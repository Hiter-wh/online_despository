import numpy as np
from scipy import spatial
import matplotlib.pyplot as plt
from matplotlib.ticker import FormatStrFormatter
from matplotlib.animation import FuncAnimation

"""
*
***both for TSP o  ***
*
https://blog.csdn.net/qq_32182397/article/details/105928093
metaclass 约等于type 实例化一个类（类是一个object在此处）
def upper_attr(class_name, class_parents, class_attr):
    '''Return a class object, with the list of its attribute turned into
    uppercase.
    '''
    # pick up any attribute that doesn't start with '__' and turn it into uppercase.
    uppercase_attr = {}
    for name, val in class_attr.items():
        if name.startswith('__'):
            uppercase_attr[name] = val
        else:
            uppercase_attr[name.upper()] = val

    # let `type` do the class creation
    return type(class_name, class_parents, uppercase_attr)
# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    class Foo(object,metaclass=upper_attr):
        # this __metaclass__ will affect the creation of this new style class

        bar = 'bar'

    print(Foo().BAR)
    print(hasattr(Foo, 'bar'))
    # True
"""
def cal_total_distance(routine):
    #num_points,=np.shape(routine)
    return sum([distance_matrix[routine[i % num_points], routine[(i + 1) % num_points]] for i in range(num_points)])
#计算总路径

class GeneticAlgorithm(object):
    # 各个属性初始化
    def __init__(self, n_dim, size_pop=50, max_iter=200, prob_mut=0.001, constraint_eq=[], constraint_ueq=[]):
        self.size_pop = size_pop  # size of population
        self.max_iter = max_iter
        self.prob_mut = prob_mut  # probability of mutation
        self.n_dim = n_dim #解的维度

        # constraint:
        self.has_constraint = len(constraint_eq) > 0 or len(constraint_ueq) > 0
        self.constraint_eq = constraint_eq  # a list of unequal constraint functions with c[i] <= 0
        self.constraint_ueq = constraint_ueq  # a list of equal functions with ceq[i] = 0

        self.Chrom = None
        self.X = None  # shape = (size_pop, n_dim),解本身
        self.Y_raw = None  # shape = (size_pop,) , f(x)，解的优劣
        self.Y = None  # shape = (size_pop,) , f(x)+penalty，调整过后解的优劣
        self.Y_aft_rnk = None  # shape = (size_pop,)

        # self.FitV_history = []
        self.generation_best_X = []
        self.generation_best_Y = []

        self.all_history_Y = []
        self.all_history_FitV = []

        #self.has_constraint = False
        self.len_chrom = self.n_dim

    # 随机初始化种群
    def init_population(self):
        # create the population
        tmp = np.random.rand(self.size_pop, self.len_chrom)#生成临时的随机矩阵，shape=（population,n_dims）
        self.Chrom = tmp.argsort(axis=1)#返回从小到大排序的索引值，但是不改变原矩阵，这样就随机生成了一个二维度int矩阵,即在n_dim维度排序序列
        return self.Chrom

    def transformDNA(self):
        self.Y_raw = np.array([cal_total_distance(x) for x in self.X])
        #计算基因表现型
        #未输入限制条件
        if not self.has_constraint:
            self.Y = self.Y_raw
        else:
            penalty_eq = np.array([np.sum(np.abs([c_i(x) for c_i in self.constraint_eq])) for x in self.X])
            penalty_ueq = np.array([np.sum(np.abs([max(0, c_i(x)) for c_i in self.constraint_ueq])) for x in self.X])
            self.Y = self.Y_raw + 1e5 * penalty_eq + 1e5 * penalty_ueq
        return self.Y
        #罚函数

    def ranking(self):
        # GA select the biggest one, but we want to minimize func, so we put a negative here
        self.Y_aft_rnk = -self.Y

    def selection(self, tourn_size=3):
        aspirants_idx = np.random.randint(self.size_pop, size=(self.size_pop, tourn_size))#生成0~pop的shape=(pop,3)的二维矩阵
        aspirants_values = self.Y_aft_rnk[aspirants_idx]#生成Y值矩阵，矩阵axis=0的每一个list里的序号（range(pop)）被映射为其代表的Y值
        #print('here!',aspirants_values)
        winner = aspirants_values.argmax(axis=1)  # winner index in every team，3选1
        sel_index = [aspirants_idx[i, j] for i, j in enumerate(winner)]
        self.Chrom = self.Chrom[sel_index, :]
        return self.Chrom#3选一淘汰若干项，而留下来了带有重复项的chrom矩阵

    def create_child(self):
        for i in range(0, self.size_pop, 2):
            Chrom1, Chrom2 = self.Chrom[i], self.Chrom[i + 1]#依次取出两条筛选后的染色体
            cxpoint1, cxpoint2 = np.random.randint(0, self.len_chrom - 1, 2)
            if cxpoint1 >= cxpoint2:
                cxpoint1, cxpoint2 = cxpoint2, cxpoint1 + 1#获取染色体交换区间
            # crossover at the point cxpoint1 to cxpoint2
            pos1_recorder = {value: idx for idx, value in enumerate(Chrom1)}
            #print(pos1_recorder,'\n and',Chrom1)
            pos2_recorder = {value: idx for idx, value in enumerate(Chrom2)}
            #保留原序列的dirc,此处value及id调换边了
            for j in range(cxpoint1, cxpoint2):
                value1, value2 = Chrom1[j], Chrom2[j]#染色体要交换处的值

                pos1, pos2 = pos1_recorder[value1], pos2_recorder[value2]#获取原染色体的值得序号
                #print('here!',j,pos1,pos2)
                #print(Chrom1[j], Chrom1[pos1],'  versus  \n')
                Chrom1[j], Chrom1[pos1] = Chrom1[pos1], Chrom1[j]#交换Chrom1【j】和Chrom[pos]的值,第一轮循环时必定j,pos1,pos2相等

                Chrom2[j], Chrom2[pos2] = Chrom2[pos2], Chrom2[j]

                pos1_recorder[value1], pos1_recorder[value2] = pos1, j
                pos2_recorder[value1], pos2_recorder[value2] = j, pos2

            self.Chrom[i], self.Chrom[i + 1] = Chrom1, Chrom2
        return self.Chrom

    def mutate_child(self):
        for i in range(self.size_pop):
            for j in range(self.n_dim):
                if np.random.rand() < self.prob_mut:
                    n = np.random.randint(0, self.len_chrom, 1)
                    self.Chrom[i, j], self.Chrom[i, n] = self.Chrom[i, n], self.Chrom[i, j]
                    #碱基对交换
        return self.Chrom

    def chrom2x(self):
        self.X = self.Chrom
        return self.X

    # 进化函数
    def evolution(self, max_iter=None):
        self.max_iter = max_iter or self.max_iter
        for i in range(self.max_iter):
            self.X = self.chrom2x()#地址变量录入

            self.transformDNA()#将解（基因）转化为表现型,本文中的基因表现为一个len=n_dims的list
            self.ranking()#自己定义的排序函数，TSP中表现为取反
            self.selection()
            self.create_child()
            self.mutate_child()

            # record the best ones
            generation_best_index = self.Y_aft_rnk.argmax()
            self.generation_best_X.append(self.X[generation_best_index, :])
            self.generation_best_Y.append(self.Y[generation_best_index])
            self.all_history_Y.append(self.Y)
            self.all_history_FitV.append(self.Y_aft_rnk)

        global_best_index = np.array(self.generation_best_Y).argmin()
        global_best_X = self.generation_best_X[global_best_index]
        global_best_Y = cal_total_distance(global_best_X)
        return global_best_X, global_best_Y

    def plot_final(self):
        fig, ax = plt.subplots(1, 2)
        best_points_ = np.concatenate([best_points, [best_points[0]]])
        best_points_coordinate = points_coordinate[best_points_, :]
        ax[0].plot(self.generation_best_Y)
        ax[0].set_xlabel("Iteration")
        ax[0].set_ylabel("Distance")
        ax[1].plot(best_points_coordinate[:, 0], best_points_coordinate[:, 1],
                   marker='o', markerfacecolor='b', color='c', linestyle='-')
        ax[1].xaxis.set_major_formatter(FormatStrFormatter('%.3f'))
        ax[1].yaxis.set_major_formatter(FormatStrFormatter('%.3f'))
        ax[1].set_xlabel("X")
        ax[1].set_ylabel("Y")
        plt.show()

    def plot_animation(self):
        best_x_history = self.generation_best_X

        fig2, ax2 = plt.subplots(1, 1)
        ax2.set_title('title', loc='center')
        line = ax2.plot(points_coordinate[:, 0], points_coordinate[:, 1],
                        marker='o', markerfacecolor='b', color='c', linestyle='-')
        ax2.xaxis.set_major_formatter(FormatStrFormatter('%.3f'))
        ax2.yaxis.set_major_formatter(FormatStrFormatter('%.3f'))
        ax2.set_xlabel("X")
        ax2.set_ylabel("Y")
        plt.ion()

        def update_scatter(frame):
            ax2.set_title('iter = ' + str(frame))
            points = best_x_history[frame]
            points = np.concatenate([points, [points[0]]])
            point_coordinate = points_coordinate[points, :]
            plt.setp(line, 'xdata', point_coordinate[:, 0], 'ydata', point_coordinate[:, 1])
            return line

        ani = FuncAnimation(fig2, update_scatter, blit=True, interval=25, frames=len(best_x_history))
        plt.show()
        ani.save('ga_tsp.gif', writer='pillow')


if __name__ == '__main__':
    points_coordinate = np.random.randint(0, 100, (20, 2))
    num_points = points_coordinate.shape[0]
    #计算随机矩阵的各个点之间的距离，shape=20,20,[]
    distance_matrix = spatial.distance.cdist(points_coordinate, points_coordinate, metric='euclidean')

    # 初始化一个GeneticAlgorithm类
    ga_tsp = GeneticAlgorithm(n_dim=num_points, size_pop=300, max_iter=800, prob_mut=0.05)
    ga_tsp.init_population()#初始化chrom矩阵
    best_points, best_distance = ga_tsp.evolution()  # 进行进化操作
    print(best_points, best_distance)
    ga_tsp.plot_final()
    ga_tsp.plot_animation()

